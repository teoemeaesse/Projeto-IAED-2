#include <stdio.h>

#include "commands.h"

void help() {
    printf("%s", HELP_CMD_TXT);
}

int quit(char * raw) {
    free(raw);
    
    return ZERO;
}

void set(FileSystem * fs, Command * command) {
    char * path, * value;

    if(command == NULL || command->tokens == NULL || command->tokens->head == NULL)
        return;
    
    path = nextToken(command);
    if(path == NULL)
        return;
    value = nextToken(command);
    if(value == NULL) {
        free(path);
        return;
    }

    addDirectory(fs, path, value);

    free(path);
    free(value);
}

void print(FileSystem * fs) {
    List * path;

    if(fs == NULL || fs->root == NULL)
        return;
    
    path = createList();

    printDirectory(fs->root, path);

    destroyList(path);
}

void find(FileSystem * fs, Command * command) {
    Directory * dir;
    List * components;
    char * path, * token;

    if(fs == NULL || command == NULL)
        return;
    
    path = nextToken(command);

    if(path == NULL)
        return;
    
    components = createList();

    token = strtok(path, PATH_SEPARATOR_STR);
    while(token != NULL) {
        insert(components, token);
        token = strtok(NULL, PATH_SEPARATOR_STR);
    }

    dir = findSubDirectory(fs->root, components);

    if(dir != NULL)
        printf("%s\n", dir->value);

    destroyList(components);
    
    free(path);
    free(token);
}